import flask
import flask.ext.sqlalchemy
import flask.ext.restless

app = flask.Flask(__name__)
app.config['DEBUG'] = True

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'

@app.after_request
def after_request(response):
  response.headers.add('Access-Control-Allow-Origin', '*')
  response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
  response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE')
  return response
  
@app.route('/')
def index():
    return app.send_static_file("index.html")

db = flask.ext.sqlalchemy.SQLAlchemy(app)

class Mybucket(db.Model):
    id = db.Column(db.Integer)
    key = db.Column(db.Unicode, unique=True, primary_key=True)
    name = db.Column(db.Unicode)

# Create the database tables.
db.create_all()

# Create the Flask-Restless API manager.
manager = flask.ext.restless.APIManager(app, flask_sqlalchemy_db=db)

# Create API endpoints, which will be available at /api/<tablename> by
# default. Allowed HTTP methods can be specified as well.
manager.create_api(Mybucket, methods=['GET', 'POST', 'DELETE'])

if __name__ == '__main__':
    # start the flask loop
    app.run(host='127.0.0.1',port=8888,debug=True)
